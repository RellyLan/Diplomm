﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace DiplommIvanov.Pages
{
    /// <summary>
    /// Логика взаимодействия для ApplicationJobPage1.xaml
    /// </summary>
    public partial class ApplicationJobPage1 : Page
    {
        public ApplicationJobPage1()
        {
            InitializeComponent();
            DGApplicationJob.ItemsSource = App.DB.Applications.ToList();
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
