﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DiplommIvanov.Pages
{
    /// <summary>
    /// Логика взаимодействия для AbiturientPage.xaml
    /// </summary>
    public partial class AbiturientPage : Page
    {
        public AbiturientPage()
        {
            InitializeComponent();
            DGAbiturient.ItemsSource = App.DB.Abiturient.ToList();
        }

        private void BBack_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
